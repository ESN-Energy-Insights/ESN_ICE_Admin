SELECT * from company

    where mqtt_topic = :companyid