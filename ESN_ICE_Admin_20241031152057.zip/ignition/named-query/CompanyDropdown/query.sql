SELECT mqtt_topic as value,company_name as label FROM company

order by company_name